import React from 'react'
import Navbar from '../src/components/navBar/navBar'
import Home from './components/home/home'
import PlayList from '../src/components/player/playList'
import {useAuth0} from '@auth0/auth0-react'

function App(){
  const {isAuthenticated, isLoading} = useAuth0();

  if (isLoading){
    return(
      <div className="loading">
        <img src={require('../src/assets/loading.gif')} alt="loading.."/>
      </div>
    )
  }
return(
  <div>
    
      <Navbar/>
      {isAuthenticated? (<PlayList/>) :
      (<Home/>)}

  </div>
)
}

export default App