import React from 'react'

function Home(){
    return(
        <div>
            <div className=" row homeGif">
                <img src={require('../../assets/home.gif')} alt="loading.."/>
            </div>
            <div className="row footer-banner footer">  
                <div  className="col-auto rights">
                    <p><h3>&copy; Copyright 2020 <a href="https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwi_1LyclK_sAhVczTgGHSwBAjYQFjABegQIAhAC&url=https%3A%2F%2Fwww.google.com%2Fgmail%2F&usg=AOvVaw3mZ_qbD_gQyp_sqkjrwStn">amit.sakhwar@gmail.com</a>.  All rights reserved.</h3></p>
                </div>
                <div className="col-auto icons">
                    <ul class="social-icons">
                        <li><a href="https://www.instagram.com/amit.sakhwar/"><i class="fa fa-instagram"></i></a></li>
                        <li><a href="https://mobile.twitter.com/amit_sakhwar"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="https://in.linkedin.com/"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
        
    )
}

export default Home;