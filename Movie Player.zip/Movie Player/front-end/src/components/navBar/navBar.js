import React from 'react'
import {Link} from 'react-router-dom'
import {useAuth0} from '@auth0/auth0-react'

function Navbar(){
    const {loginWithRedirect, logout, isAuthenticated} = useAuth0();
    return(
        <div className="row navbar">
            <div className="col-auto">
                <h1>Movie Player</h1>
            </div>
            <div className="col-auto navbar_button">
                {!isAuthenticated ? (<button onClick={()=> loginWithRedirect()}>
                   <h3>Login</h3>
                </button>) :
                (<button onClick={()=> logout()}>
                    <h3>Logout</h3>
                </button>)}
            </div>
        </div>
    )
}

export default Navbar