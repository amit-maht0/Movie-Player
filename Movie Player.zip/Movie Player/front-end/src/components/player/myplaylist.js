import React,{useState} from 'react'
import Item from "./Item";


function MyPlayList(props){

    return (
        <div className="playlist_img">
            <Item>
                <img id="reflection" src={props.playlist.poster} onClick={()=> props.handleUrl(props.playlist)}/>
                <div className="row playlist_title">
                    <h3>{props.playlist.name}</h3>
                    <h4>{props.playlist.year}</h4>
                </div>
            </Item>          
        </div> 
       
        
)
}

export default MyPlayList