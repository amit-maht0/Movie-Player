import React,{useState} from 'react'
import videoObject from '../videoObject'
import MyPlayList from './myplaylist'
import Carousel from "react-elastic-carousel"
import MoviePlayer from './moviePlayer'
import {useAuth0} from '@auth0/auth0-react'

const breakPoints = [
    { width: 1, itemsToShow: 1 },
    // { width: 550, itemsToShow: 2, itemsToScroll: 2 },
    // { width: 768, itemsToShow: 3 },
    // { width: 1200, itemsToShow: 4 }
  ];


function PlayList(){

    const {user} = useAuth0();
    const [myplayer, setPlayer] = useState(true);
    const [urlplayer, setUrlPlayer] = useState("");
    
    function handleUrl(item){
        
        setPlayer(false);
        setUrlPlayer(item.trailer)
    }

    const playlistComp = videoObject.map(playlist =>{
        return(
            <MyPlayList key={playlist.Id} playlist={playlist} handleUrl={handleUrl}/>
        )
    })
    return(
        <div>
    {myplayer ? (
        <div>
            <div className="row playlist_header">
                <h4>Playlist</h4>
            </div>
            <Carousel breakPoints={breakPoints}>
                {playlistComp}
            </Carousel>
        </div>  
            ) : 
            (<div>
                <div className="videoplayer">
                    <button onClick={()=> {setPlayer(true)}}>
                        <h3>Back</h3>
                    </button>
                </div>
                <MoviePlayer urlplayer={urlplayer} />
            </div>)
        }
            </div>
        
        
    )
}

export default PlayList