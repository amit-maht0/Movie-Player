var videoObject = [
    {
      Id:0,
      name: "Avengers: End Game",
      trailer: "https://s3.ap-south-1.amazonaws.com/s3.gmi/sample/EndGame.mp4",
      poster: "https://gamespot1.cbsistatic.com/uploads/scale_super/1578/15789737/3515432-endgamedek.jpg",
      year: "2018"
    },
    {
      Id:1,
      name: "Joker",
      trailer: "https://s3.ap-south-1.amazonaws.com/s3.gmi/sample/Joker.mp4",
      poster: "http://i0.wp.com/see.news/wp-content/uploads/2020/02/amirhosein-naseri-desktop-screenshot-2019-04-03-18-17-47-11.jpg?resize=750%2C375&ssl=1",
      year: "2019"
    },
    {
      Id:2,
      name: "Man Of Steel",
      trailer: "https://s3.ap-south-1.amazonaws.com/s3.gmi/sample/ManOfSteel.mp4",
      poster: "https://cdn.europosters.eu/image/750/posters/superman-man-of-steel-cape-i14560.jpg",
      year: "2018"
    },
    {
      Id:3,
      name: "Suryavanshi",
      trailer: "https://s3.ap-south-1.amazonaws.com/s3.gmi/sample/Suryavanshi.mp4",
      poster: "http://justnewsly.com/wp-content/uploads/suryavanshm.jpg",
      year: "2020"
    },
    {
      Id:4,
      name: "Black Widow",
      trailer: "https://s3.ap-south-1.amazonaws.com/s3.gmi/sample/blackwidow.mp4",
      poster: "https://images2.alphacoders.com/106/thumb-1920-1060159.jpg",
      year: "2020"
    }
  ]

  export default videoObject
